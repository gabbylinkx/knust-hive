-- ============================================================
-- KNUST Hive — Supabase schema
-- Run in the Supabase SQL editor, top to bottom, on a fresh project.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- Verified student IDs (uploaded each semester by registrar) ----------
create table verified_student_ids (
  student_id text primary key,
  full_name text,
  faculty text,
  imported_at timestamptz default now()
);

-- ---------- Profiles (extends auth.users) ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  student_id text not null unique,
  display_name text not null,
  faculty text,
  department text,
  year_group int,
  interests text[] default '{}',
  avatar_url text,
  created_at timestamptz default now()
);

-- Reject sign-ups whose student_id isn't in the registrar's verified list.
create or replace function check_student_id()
returns trigger as $$
begin
  if not exists (select 1 from verified_student_ids where student_id = new.student_id) then
    raise exception 'Student ID % is not recognized. Contact IT support if this is an error.', new.student_id;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_check_student_id
  before insert on profiles
  for each row execute function check_student_id();

-- ---------- Stops (shuttle) ----------
create table stops (
  id text primary key,
  name text not null,
  route text not null check (route in ('green', 'gold')),
  lat double precision,   -- nullable until GPS survey is done
  lng double precision,
  is_hub boolean default false
);

-- ---------- Shuttle sightings (crowdsourced) ----------
create table shuttle_reports (
  id uuid primary key default uuid_generate_v4(),
  stop_id text not null references stops(id),
  route text not null check (route in ('green', 'gold')),
  reported_by uuid not null references profiles(id),
  created_at timestamptz default now()
);
create index on shuttle_reports (created_at desc);

-- ---------- Ride board ----------
create table ride_posts (
  id uuid primary key default uuid_generate_v4(),
  type text not null check (type in ('need', 'offer')),
  from_stop_id text not null references stops(id),
  to_stop_id text not null references stops(id),
  time_label text not null,
  note text,
  posted_by uuid not null references profiles(id),
  created_at timestamptz default now()
);

-- ---------- Campus feed ----------
create table feed_posts (
  id uuid primary key default uuid_generate_v4(),
  category text not null check (category in ('event', 'lostFound', 'shoutout', 'studyGroup')),
  text text not null,
  posted_by uuid not null references profiles(id),
  rsvp_count int default 0,
  created_at timestamptz default now()
);

create table event_rsvps (
  post_id uuid references feed_posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (post_id, user_id)
);

-- ---------- Communities ----------
create table communities (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  description text
);

create table community_members (
  community_id uuid references communities(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (community_id, user_id)
);

-- ---------- Chat ----------
create table chats (
  id uuid primary key default uuid_generate_v4(),
  is_group boolean default false,
  is_anonymous_wall boolean default false, -- confession wall
  name text,
  created_at timestamptz default now()
);

create table chat_members (
  chat_id uuid references chats(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (chat_id, user_id)
);

create table messages (
  id uuid primary key default uuid_generate_v4(),
  chat_id uuid references chats(id) on delete cascade,
  sender_id uuid references profiles(id),
  text text not null,
  flagged boolean default false, -- set by moderation function before showing on wall
  created_at timestamptz default now()
);
create index on messages (chat_id, created_at);

-- ---------- Skills ----------
create table skill_paths (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  tag text,
  description text,
  resource_url text
);

create table user_skill_progress (
  user_id uuid references profiles(id) on delete cascade,
  skill_id uuid references skill_paths(id) on delete cascade,
  status text default 'started' check (status in ('started', 'completed')),
  updated_at timestamptz default now(),
  primary key (user_id, skill_id)
);

create table mentorships (
  mentor_id uuid references profiles(id),
  mentee_id uuid references profiles(id),
  status text default 'pending' check (status in ('pending', 'active', 'ended')),
  created_at timestamptz default now(),
  primary key (mentor_id, mentee_id)
);

-- ---------- Academics ----------
create table timetable_entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  course_name text not null,
  day_of_week int not null check (day_of_week between 0 and 6),
  start_time time not null,
  end_time time not null,
  room text,
  -- prevents two entries for the same user overlapping in time
  exclude using gist (
    user_id with =,
    day_of_week with =,
    tsrange('2000-01-01'::date + start_time, '2000-01-01'::date + end_time) with &&
  )
);

create table gpa_records (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  course_code text not null,
  credit_hours numeric not null,
  grade text not null,
  semester text not null
);

-- ---------- Marketplace ----------
create table marketplace_listings (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid references profiles(id),
  title text not null,
  price numeric,
  description text,
  image_url text,
  status text default 'available' check (status in ('available', 'sold')),
  created_at timestamptz default now()
);

-- ---------- Past questions repository ----------
create table past_questions (
  id uuid primary key default uuid_generate_v4(),
  course_code text not null,
  year int,
  file_url text not null, -- Supabase Storage path
  uploaded_by uuid references profiles(id)
);

-- ============================================================
-- Row Level Security
-- ============================================================
alter table profiles enable row level security;
alter table shuttle_reports enable row level security;
alter table ride_posts enable row level security;
alter table feed_posts enable row level security;
alter table messages enable row level security;
alter table chat_members enable row level security;

create policy "profiles are viewable by any signed-in student"
  on profiles for select using (auth.role() = 'authenticated');
create policy "users manage their own profile"
  on profiles for update using (auth.uid() = id);

create policy "reports viewable by all, insertable by owner"
  on shuttle_reports for select using (true);
create policy "reports insertable by signed-in students"
  on shuttle_reports for insert with check (auth.uid() = reported_by);

create policy "ride posts viewable by all"
  on ride_posts for select using (true);
create policy "ride posts insertable by owner"
  on ride_posts for insert with check (auth.uid() = posted_by);
create policy "ride posts deletable by owner"
  on ride_posts for delete using (auth.uid() = posted_by);

create policy "feed viewable by all"
  on feed_posts for select using (true);
create policy "feed insertable by owner"
  on feed_posts for insert with check (auth.uid() = posted_by);
create policy "feed deletable by owner"
  on feed_posts for delete using (auth.uid() = posted_by);

create policy "messages viewable only by chat members"
  on messages for select using (
    exists (select 1 from chat_members cm where cm.chat_id = messages.chat_id and cm.user_id = auth.uid())
  );
create policy "messages insertable only by chat members"
  on messages for insert with check (
    exists (select 1 from chat_members cm where cm.chat_id = messages.chat_id and cm.user_id = auth.uid())
  );

-- ============================================================
-- Enable Realtime on the tables the app streams from
-- ============================================================
alter publication supabase_realtime add table shuttle_reports;
alter publication supabase_realtime add table ride_posts;
alter publication supabase_realtime add table feed_posts;
alter publication supabase_realtime add table messages;

-- ============================================================
-- Seed: campus stops
-- ============================================================
insert into stops (id, name, route, is_hub) values
  ('g0', 'Main Gate', 'green', false),
  ('g1', 'Republic Hall', 'green', false),
  ('g2', 'Katanga', 'green', false),
  ('hub', 'Commercial Area', 'green', true),
  ('g3', 'Engineering', 'green', false),
  ('g4', 'Business School', 'green', false),
  ('g5', 'Conti Campus', 'green', false),
  ('y0', 'Bomso Gate', 'gold', false),
  ('y1', 'Ayeduase Gate', 'gold', false),
  ('y2', 'Unity Hall', 'gold', false),
  ('y3', 'Africa Hall', 'gold', false),
  ('y4', 'Queens Hall', 'gold', false),
  ('y5', 'Univ. Hospital', 'gold', false)
on conflict (id) do nothing;
