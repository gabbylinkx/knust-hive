# KNUST Hive

Campus dashboard, feed, skills hub, and a live crowdsourced shuttle tracker
for KNUST students. Flutter + Riverpod + Supabase.

## What's fully built
- Auth (email/password + student-ID verification trigger, Google OAuth hook)
- Dashboard (schedule, to-do, stats, announcements)
- Shuttle tracker — schematic live map, crowdsourced sighting reports,
  ride board — all realtime via Supabase `.stream()`
- Campus feed with categories (events, lost & found, shoutouts, study groups)
- Skills hub with external resources and local progress tracking
- Full Postgres schema with Row Level Security for everything above,
  **plus** tables for chat, communities, mentorship, timetable/GPA,
  marketplace, and past questions — ready for the screens below

## What's scaffolded, not wired
Chat, communities, mentorship matching, portfolio builder, timetable
conflict UI, GPA calculator, marketplace, past-questions repo, SOS button,
admin/moderation panel. Each has a table in `supabase/schema.sql` and,
where relevant, a comment in the code pointing at the pattern to copy
(`shuttle_providers.dart` is the reference implementation for "stream a
table + insert/delete actions").

## 1. Prerequisites
- Flutter 3.22+ (`flutter --version`)
- A free [Supabase](https://supabase.com) project
- (Optional, for push notifications) a Firebase project

## 2. Supabase setup
1. Create a project at supabase.com.
2. Open the SQL editor, paste and run `supabase/schema.sql` top to bottom.
3. Before real students can sign up, load `verified_student_ids` with the
   registrar's export (CSV import works fine in the Supabase table UI).
4. Project Settings → API: copy your **Project URL** and **anon public key**.
5. (Optional) `supabase functions deploy notify_nearby` for shuttle push
   notifications, then wire a Database Webhook on `shuttle_reports` INSERT.

## 3. Run locally
```bash
flutter pub get
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

## 4. Push notifications (Firebase Cloud Messaging)
```bash
dart pub global activate flutterfire_cli
flutterfire configure
```
This generates `lib/firebase_options.dart`. Then uncomment the
`Firebase.initializeApp(...)` line in `lib/main.dart` and add a
`core/services/push_service.dart` that requests permission and registers
the FCM token into a new `device_tokens` table.

## 5. App icon, name, splash
- Update `pubspec.yaml` `name`/`description` as needed.
- Add `flutter_launcher_icons` and `flutter_native_splash` packages for
  branded icon/splash generation from a single source image.

## 6. Google Sign-In
Enable the Google provider in Supabase Auth settings, and follow
Supabase's [Flutter OAuth guide](https://supabase.com/docs/guides/auth/social-login/auth-google)
to register OAuth client IDs for Android/iOS (needed for the native flow).

## 7. Deployment
**Android (Play Store)**
```bash
flutter build appbundle --release \
  --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
Upload `build/app/outputs/bundle/release/app-release.aab` via the
Play Console. You'll need a signing keystore — see Flutter's
[Android deployment guide](https://docs.flutter.dev/deployment/android).

**iOS (App Store)**
```bash
flutter build ipa --release \
  --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
Open the generated Xcode archive, or use `xcrun altool` / Transporter to
upload. Requires an active Apple Developer account. See Flutter's
[iOS deployment guide](https://docs.flutter.dev/deployment/ios).

## 8. Admin/moderation panel
Not built here — for a small team, the fastest path is a second, thin
Flutter web app (or a simple Supabase Studio-backed internal tool) that
signs in with an `is_admin` flag on `profiles` and lets moderators flag
rows in `messages`/`feed_posts` and unpublish `marketplace_listings`.
RLS policies would need an `is_admin` bypass clause added per table.

## Suggested build order from here
1. Wire chat (copy the shuttle/feed streaming pattern onto `messages`)
2. Timetable + GPA screens (schema already enforces no double-booking)
3. Marketplace + past-questions (both mostly CRUD + Storage uploads)
4. Admin panel
5. Offline write queue (Hive-backed) so posts made with no signal sync
   once connectivity returns — currently reads are cache-friendly but
   writes require a live connection
